<?php
include "config.php";
  if (isset($_POST['submit'])) {
     $id_subjectinfo  = $_POST['id_subjectinfo'];
	 $id_subject = $_POST['id_subject'];
	 $id_employee = $_POST['id_employee'];
	 $id_timeandwhere = $_POST['id_timeandwhere'];
	 $id_student = $_POST['id_student'];
	 $sql = "INSERT INTO `subjectinfo_table`(`id_subjectinfo`, `id_subject`, `id_employee`, `id_timeandwhere`, `id_student`) VALUES ('$id_subjectinfo', '$id_subject', '$id_employee', '$id_timeandwhere', '$id_student')";
	 $result = $conn->query($sql);

     if ($result == TRUE) {
	  echo "New record created succesfully.";
	 }else{
	  echo "Error:". $sql . "<br>". $conn->error;
	 }
	 $conn->close();
  }
?>

<!DOCTYPE html>
<html>
<body>
<h2>STUDENT SUBJECTS</h2>
<form action="" method="POST">
  <fieldset>
	 <legend>Course information:</legend>
	 ID:<br>
	 <input type="number" name="id_subjectinfo">
	 <br>
	 Subject:<br>
	 <input type="number" name="id_subject">
	 <br>
	 Instructor:<br>
	 <input type="number" name="id_employee">
	 <br>
	 Time:<br>
	 <input type="number" name="id_timeandwhere">
	 <br>
	 Student:<br>
	 <input type="number" name="id_student">
	 <br><br>
	 <input type="submit" name="submit" value="Submit">
  </fieldset>
</form>
</body>
</html>