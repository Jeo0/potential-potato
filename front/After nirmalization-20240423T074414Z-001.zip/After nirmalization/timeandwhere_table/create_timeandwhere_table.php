<?php
include "config.php";
  if (isset($_POST['submit'])) {
     $id_timeandwhere = $_POST['id_timeandwhere'];
	 $time = $_POST['time'];
	 $id_establishment = $_POST['id_establishment'];
	 $id_section = $_POST['id_section'];
	 $sql = "INSERT INTO `timeandwhere_table`(`id_timeandwhere`, `time`, `id_establishment`, `id_section`) VALUES ('$id_timeandwhere', '$time', '$id_establishment', '$id_section')";
	 $result = $conn->query($sql);

     if ($result == TRUE) {
	  echo "New record created succesfully.";
	 }else{
	  echo "Error:". $sql . "<br>". $conn->error;
	 }
	 $conn->close();
  }
?>

<!DOCTYPE html>
<html>
<body>
<h2>SCHEDULE</h2>
<form action="" method="POST">
  <fieldset>
	 <legend>Course information:</legend>
	 ID:<br>
	 <input type="number" name="id_timeandwhere">
	 <br>
	 Time:<br>
	 <input type="time" name="time">
	 <br>
	 Establishment:<br>
	 <input type="number" name="id_establishment">
	 <br>
	 Section:<br>
	 <input type="number" name="id_section">
	 <br><br>
	 <input type="submit" name="submit" value="Submit">
  </fieldset>
</form>
</body>
</html>