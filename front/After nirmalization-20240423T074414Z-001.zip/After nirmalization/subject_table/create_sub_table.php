<?php
include "config.php";
  if (isset($_POST['submit'])) {
	 $id_subject = $_POST['id_subject'];
	 $subject_name = $_POST['subject_name'];;
	 $sql = "INSERT INTO `subject_table`(`id_subject`, `subject_name`) VALUES ('$id_subject','$subject_name')";
	 $result = $conn->query($sql);
	 if ($result == TRUE) {
	  echo "New record created succesfully.";
	 }else{
	  echo "Error:". $sql . "<br>". $conn->error;
	 }
	 $conn->close();
  }
?>

<!DOCTYPE html>
<html>
<body>
<h2>SUBJECTS</h2>
<form action="" method="POST">
  <fieldset>
	<legend>
	</legend>
	Subject ID:<br>
	<input type="number" name="id_subject">
	<br>
	Subject Name:<br>
	<input type="text" name="subject_name">
	<br><br>
	<input type="submit" name="submit" value="Submit">
  </fieldset>
</form>
</body>
</html>