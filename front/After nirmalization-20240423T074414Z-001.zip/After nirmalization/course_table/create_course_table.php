<?php
include "config.php";
  if (isset($_POST['submit'])) {
     $id_course = $_POST['id_course'];
	 $coursename = $_POST['coursename'];
	 $sql = "INSERT INTO `courses_table`(`id_course`, `coursename`) VALUES ('$id_course', '$coursename')";
	 $result = $conn->query($sql);

     if ($result == TRUE) {
	  echo "New record created succesfully.";
	 }else{
	  echo "Error:". $sql . "<br>". $conn->error;
	 }
	 $conn->close();
  }
?>

<!DOCTYPE html>
<html>
<body>
<h2>STUDENT COURSES</h2>
<form action="" method="POST">
  <fieldset>
	 <legend>Course information:</legend>
	 Course ID:<br>
	 <input type="number" name="id_course">
	 <br>
	 Course Name:<br>
	 <input type="text" name="coursename">
	 <br><br>
	 <input type="submit" name="ubmit" value="Submit">
  </fieldset>
</form>
</body>
</html>