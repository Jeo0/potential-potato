<?php
include "config.php";
$sql = "SELECT * FROM courses_table";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>View Page</title>
<link rel ="stylesheet" href ="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
</head>

<body>
	<div class = "container">
		<h2>STUDENT COURSES</h2>
<table class ="table">
	<thead>
		<tr>
		<th>Course ID</th>
		<th>Course Name</th>
		<th>Action</th>
	</tr>
	</thead>
	<tbody>
		
		<?php
			if ($result->num_rows > 0) {
				while ($row = $result->fetch_assoc()) {
		?>
				<tr>
					<td><?php echo $row['id_course']; ?></td>
					<td><?php echo $row['coursename']; ?></td>
					<td><a class = "btn btn-info" href = "update_course_table.php?id=<?php echo $row['id_course']; ?>">
						Edit</a>
					&nbsp;
					<a class = "btn btn-danger" href = "delete_course_table.php?id = <?php echo $row['id_course']; ?>">
						Delete</a>
					</td>
				</tr>
		<?php 		}
			}
		?>
	</tbody>
</table>
	</div>
</body>
</html>